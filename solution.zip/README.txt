TODO: add information about contributions of team member(s)

Name: Yoohyuk Chang

Yoohyuk Chang(I) worked on uint256_create_from_u32, uint256_create, and uint256_get_bits functions.

